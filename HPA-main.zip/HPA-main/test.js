import http from 'k6/http';
import { sleep } from 'k6';

export const options = {
  vus: 2000,           
  duration: '30m',      
 };

export default function () {
  http.get('https://elearn.daffodilvarsity.edu.bd/?redirect=0');
  
  sleep(5);
}
